package com.example.goonjnew;

class Record implements java.io.Serializable
{
        long rowid;
        String groupid;
        String key, value, user, datatype, synched;
        long timestamp;
}