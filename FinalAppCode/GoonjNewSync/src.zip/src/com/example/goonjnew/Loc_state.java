package com.example.goonjnew;

public class Loc_state implements java.io.Serializable {

	int id;
	String name;
	int country_id;
	
	public void doJob(Object obj)
	{
		//insert into db here
	}
}
