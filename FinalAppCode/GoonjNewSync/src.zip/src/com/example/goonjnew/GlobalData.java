package com.example.goonjnew;

public class GlobalData {

	public static String IPAdd;
	public static Story fetched;
	public static String groupid;
	public static String namespace;
	public static boolean issue_assigned = false;
	public static Helper dh;
}
