package com.example.goonjnew;

public class StoryCrepRelation implements java.io.Serializable {

	int scr_id;
	int story_id;
	int crep_id;
	
	public void doJob(Object obj)
	{
		//insert values into db here
	}
}
