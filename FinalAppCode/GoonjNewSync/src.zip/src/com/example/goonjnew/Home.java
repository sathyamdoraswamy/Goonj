package com.example.goonjnew;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class Home extends Activity
{			
	public void onCreate(Bundle savedInstanceState)
	{		
	    super.onCreate(savedInstanceState);
     
	    Helper dh = new Helper(this,"example.db","datastore",1);
		dh.setIP("10.193.11.234");
		//dh.close();
		
		Log.d("ABCDEFGHI","STARTING SERVICES NOW!!!");

		Intent stubser=new Intent(this, ClientStubService.class);
		stubser.putExtra("com.androidbook.ClientStubService.UID","1525");
		startService(stubser);
		  
//		Intent pullser=new Intent(this, ClientPullService.class);
//		pullser.putExtra("com.androidbook.ClientPullService.UID","1525");
//		startService(pullser);
		   		
    	Intent i = new Intent(this, Goonj.class);	    	
    	startActivity(i);	    	        	 	      
    }
}