package com.example.goonjnew;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;
//import android.util.Pair;
public class Helper {

	

	/* The database name, Version Info and the table name are given*/


	/*
	 * We need functions for the following:
	 * 1. Create repository , at first. - check if db already available.
	 * 2. * Define the record formatdb.execSQL("UPDATE "+CLIENT_TABLE+" SET synched='Y' WHERE key ='"+key+"' AND timestamp = "+timestamp+" AND synched ='N' ");
	 * 3. * get every possible thing, given wildcards.
	 * 4. * put record into table. - a insert function and a separate put which converts i/p into record format.
	 * 5. remove unnecessary arguments and variables.
	 * 6. 
	 * 7. How to include the services in our application - we need to write an instruction manual.
	 * */
	

	private static final String DATABASE_NAME ="frameworkdb_client";
	private static final int DATABASE_VERSION = 1;
	private static final String CLIENT_TABLE="phone" ;
	private static final String NAMESPACES_TABLE = "namespaces";	
	
	int userid;


	private Context context; /* The current context in which the function is called*/
	private SQLiteDatabase db;

	private SQLiteStatement insertStmt, insertStmt1, insertStmt_namespaces, insertUname;

	/* The INSERT string - the tsring form f the insert statement is given*/
	private static final String INSERT = "insert into "+ CLIENT_TABLE + " values (?,?,?,?,?,?,?,?)";	
	private static final String NAMESPACES_INSERT = "insert into "+ NAMESPACES_TABLE + " values (?,?,?,?,?)";	
	public OpenHelper openHelper;
	public Helper(Context context,String str,String stt,int userid) {

		this.context = context;
		this.userid=userid;

		/*We create a helper class to manage database creation and version management.*/
		openHelper = new OpenHelper(this.context);

		/* db is like a database handler*/
		this.db = openHelper.getWritableDatabase();

		this.insertStmt = this.db.compileStatement(INSERT);
		//this.insertStmt1 = this.db.compileStatement(INSERT1);
		this.insertStmt_namespaces = this.db.compileStatement(NAMESPACES_INSERT);

	}
	  
	public void setSynched(ArrayList<Record> r)
	{
		for(int i=0;i<r.size();i++)
		{
			db.execSQL("UPDATE "+CLIENT_TABLE+" SET synched='Y' WHERE groupid = '"+r.get(i).groupid+"' AND key = '"+r.get(i).key+"' AND value = '"+r.get(i).value+"' AND timestamp = "+r.get(i).timestamp+" AND synched ='N' ");
		}
	}
	public void close()
	{
		openHelper.close();
	}
	public void setIP(String add)
	{
		GlobalData.IPAdd=add;
	} 

	public long subscribeToNamespace(String userid, String namespace, String permission)
	{
		this.insertStmt_namespaces.bindString(1,"ADD");
		this.insertStmt_namespaces.bindString(2,userid);
		this.insertStmt_namespaces.bindString(3,namespace);
		this.insertStmt_namespaces.bindString(4,permission);
		this.insertStmt_namespaces.bindLong(5,System.currentTimeMillis());
		return this.insertStmt_namespaces.executeInsert();
	}

	public long unsubscribeFromNamespace(String userid, String namespace, String permission)
	{
		this.insertStmt_namespaces.bindString(1,"REMOVE");
		this.insertStmt_namespaces.bindString(2,userid);
		this.insertStmt_namespaces.bindString(3,namespace);
		this.insertStmt_namespaces.bindString(4,permission);
		this.insertStmt_namespaces.bindLong(5,System.currentTimeMillis());
		return this.insertStmt_namespaces.executeInsert();
		//db.execSQL("delete from "+NAMESPACES_TABLE+" where userid='"+userid+"' and namespace='"+namespace+"' and permission='"+permission+"'");
	}
	
	public ArrayList<String[]> getNamespaces() {
		ArrayList<String[]> records = new ArrayList<String[]>();
		Cursor cursor=db.query(NAMESPACES_TABLE, new String[] {"method","userid","namespace","permission"},null, null, null, null, "timestamp");
		//this.db.execSQL("SELECT * FROM "+CLIENT_TABLE+" WHERE KEY LIKE '%@%@%@%");		
		if (cursor.moveToFirst()) {
			do {
				records.add(new String[]{cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3)});
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return records;
	}
	
	public void removeNamespace(String userid, String namespace, String permission)
	{
		db.execSQL("DELETE FROM "+NAMESPACES_TABLE+" WHERE userid='"+userid+"' AND namespace='"+namespace+"' AND permission='"+permission+"';");	
	}
	


	public int getID()
	{
		String s = Long.toString(System.currentTimeMillis());
		//System.out.println(s.substring(4));
		int r = Integer.parseInt(s.substring(4));
		//System.out.println(r);
		return r;
	}
	public void puttoRepository(String key,String value,String datatype)
	{			   
		String groupid = UUID.randomUUID().toString();//getID();
		String user = "SATHYAM";
		long timestamp = System.currentTimeMillis();
		insert(0,groupid,key, value, user, datatype, timestamp, "N");
		Log.d("CHECK INSERT",Long.toString(System.currentTimeMillis()));
	}

	public void putObject(Object obj, String namespace)
	{
		try
		{
			Class c = obj.getClass();
			String className = c.getName();
			Field[] fields = c.getDeclaredFields(); 
			Record[] r = new Record[fields.length];
			int i = 0;		
			System.out.println("ENTERING LOOP NOW");
			for(Field f:fields)
			{		
				r[i] = new Record();
				String fieldName = f.getName();
				r[i].key = namespace + "." + className + "." + fieldName;            
				r[i].value = "";
				if(f.get(obj)!=null)
				{
					r[i].value = f.get(obj).toString();								
					if(fieldName.contains("Path"))
						r[i].datatype = "file";
					else
						r[i].datatype = "data";
				}
				else
				{
					r[i].datatype = "";
					r[i].value = "";					
				}
				i++;					
			}
			System.out.println("EXXITING LOOP NOW");
			putToRepository(r);		       
		}
		catch(Exception e){e.printStackTrace();}
	}
	
	public void updateObject(String groupid, Object obj, String namespace)
	{
		try
		{
			Class c = obj.getClass();
			String className = c.getName();
			Field[] fields = c.getDeclaredFields(); 
			Record[] r = new Record[fields.length];
			int i = 0;			   
			for(Field f:fields)
			{		
				r[i] = new Record();
				r[i].groupid = groupid;
				String fieldName = f.getName();
				r[i].key = namespace + "." + className + "." + fieldName;            
				r[i].value = "";
				if(f.get(obj)!=null)
				{
					r[i].value = f.get(obj).toString();	
					if(fieldName.contains("path"))
						r[i].datatype = "file";
					else
						r[i].datatype = "data";    
				}
				else
				{					
					r[i].datatype = "";
					r[i].value = "";
				}										
				i++;					
			}
			updateRepository(groupid,r);		       
		}
		catch(Exception e){e.printStackTrace();}
	}
	
	public void updateRepository(String groupid, Record[] r)
	{
		for(int i=0;i<r.length;i++)
		{
			System.out.println("UPDATE "+CLIENT_TABLE+" SET value='"+r[i].value+"', datatype='"+r[i].datatype+"', synched='N' WHERE groupid = '"+r[i].groupid+"' AND key = '"+r[i].key+"' AND value <> '"+r[i].value+"'");
			db.execSQL("UPDATE "+CLIENT_TABLE+" SET value='"+r[i].value+"', datatype='"+r[i].datatype+"', synched='N' WHERE groupid = '"+r[i].groupid+"' AND key = '"+r[i].key+"' AND value <> '"+r[i].value+"'");
		}
	}
	
	public long selectMaxRecordId()
	{
		int r = 0;
		Cursor cursor = db.rawQuery("SELECT MAX(RECORDID) FROM "+CLIENT_TABLE, null);
		if(cursor.moveToFirst())
			r = cursor.getInt(0);
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return r;
	}	
	public ArrayList<Record> getRecords(String className) {
		ArrayList<Record> records = null;
		Cursor cursor=db.query(CLIENT_TABLE, new String[] {"groupid","key","value","user", "datatype", "timestamp","synched"},"key like '%"+className+"%'", null, null, null, "groupid");
		//this.db.execSQL("SELECT * FROM "+CLIENT_TABLE+" WHERE KEY LIKE '%@%@%@%");		
		if (cursor.moveToFirst()) {
			records = new ArrayList<Record>();
			System.out.println("ASSIGNED NEW RECORDS");
			do {
				Record r = new Record();
				r.groupid = cursor.getString(0);
                r.key = cursor.getString(1);
                r.value = cursor.getString(2);
                r.user = cursor.getString(3);
                r.datatype = cursor.getString(4);
                r.timestamp = Long.parseLong(cursor.getString(5));
                r.synched =cursor.getString(6);
                records.add(r);				
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		return records;
	}
    private String getValue(ArrayList<Record> ans,String name)
    {
    	System.out.println("Name is:"+name);
        for(int i=0;i<ans.size();i++)
        {
            String key = ans.get(i).key;
            System.out.println(key.substring(key.lastIndexOf(".")+1));
            if(name.equals(key.substring(key.lastIndexOf(".")+1)))
            {            	
            	return ans.get(i).value;
            }
                    
        }
        return null;
    }
	public Object getObject(String className) {        
        ArrayList<Record> records = getRecords(className);
        if (records != null) {
            try {
                Class c = Class.forName(className);
                Field[] fields = c.getDeclaredFields();
                Object obj = c.newInstance();
                int i = 0;
                for (Field f : fields) {
                    String name = f.getName();
                    String type = f.getType().toString();
                    String value = getValue(records,name);//records.get(i).value;
                    System.out.println(name + " " + type + " " + value);
                    if (type.equals("int")) {
                        f.set(obj, (Integer.parseInt(value)));
                    }
                    if (type.equals("float")) {
                        f.set(obj, Long.parseLong(value));
                    }
                    if (type.equals("float")) {
                        f.set(obj, (Float.parseFloat(value)));
                    }
                    if (type.equals("double")) {
                        f.set(obj, (Double.parseDouble(value)));
                    }
                    if (type.equals("class java.lang.String")) {
                        f.set(obj, (value));
                    }
                    if (type.equals("char")) {
                        f.set(obj, value.charAt(0));
                    }
                    i++;
                }
                return obj;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }
	
	 public Object getObject(String className, ArrayList<Record> records) {        
	        if (records != null) {
	            try {
	                Class c = Class.forName(className);
	                Field[] fields = c.getDeclaredFields();
	                Object obj = c.newInstance();
	                int i = 0;
	                for (Field f : fields) {
	                    String name = f.getName();
	                    String type = f.getType().toString();
	                    String value = getValue(records,name);//records.get(i).value;
	                    System.out.println(name + " " + type + " " + value);
	                    if (type.equals("int")) {
	                        f.set(obj, (Integer.parseInt(value)));
	                    }
	                    if (type.equals("long")) {
	                        f.set(obj, Long.parseLong(value));
	                    }
	                    if (type.equals("float")) {
	                        f.set(obj, (Float.parseFloat(value)));
	                    }
	                    if (type.equals("double")) {
	                        f.set(obj, (Double.parseDouble(value)));
	                    }
	                    if (type.equals("class java.lang.String")) {
	                        f.set(obj, (value));
	                    }
	                    if (type.equals("char")) {
	                        f.set(obj, value.charAt(0));
	                    }
	                    i++;
	                }
	                return obj;
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	        return null;
	    }
	    
	    public ArrayList<Pair> getObjects(String className)
	    {
	        ArrayList<Record> records = getRecords(className);
	        if(records!=null)
	        {
	        	String key = records.get(0).key;
	        	String namespace = key.substring(0,key.indexOf("."));
	        	System.out.println("NAMESPACE IS:"+namespace);
	            ArrayList<Pair> objects = new ArrayList<Pair>();
	            int l = records.size();
	            Record p = records.get(0);
	            Record c = records.get(0);
	            int i=0;
	            while(i<l)
	            {
	                ArrayList<Record> r = new ArrayList<Record>(); 
	                Pair o = new Pair();
	                while(p.groupid.equals(c.groupid))
	                {                      
	                    r.add(c);                	                                   
	                    p = c;
	                    i++;
	                    if(i==l)
	                        break;
	                    c = records.get(i);
	                }
	                for(int f=0;f<r.size();f++)
	                	printRecord(r.get(f));
	                o.groupid = p.groupid;	
	                o.namespace = namespace;
	                o.obj = getObject(className, r);
	                objects.add(o);   
	                p = c;
	            }
	            return objects;
	        }
	        System.out.println("RETURNING NULL AS RECORDS IN NULL");
	        return null;
	    }
	    public void printRecord(Record r)
	    {
	    	System.out.println("PRINTING RECORDS" +r.datatype + " " + r.groupid + " " + r.key);
	    }
	public void putToRepository(Record[] records)
	{
		String groupid = UUID.randomUUID().toString(); //getID();
		String user = "SATHYAM";
		long timestamp = System.currentTimeMillis();
		for(int i=0;i<records.length;i++)
		{
			insert(0,groupid,records[i].key, records[i].value, user, records[i].datatype, timestamp, "N");				   
		}
		Log.d("CHECK INSERT",Long.toString(System.currentTimeMillis()));
	}

   public void putToRepository(long rowid,String gid,String key,String value,String user,String datatype,long timestamp,String synched)
   {			   
	   insert(rowid,gid,key, value, user, datatype, timestamp, synched);
	   Log.d("CHECK INSERT",Long.toString(System.currentTimeMillis()));
   }

	public void setSynched(String key, long timestamp)
	{
		db.execSQL("UPDATE "+CLIENT_TABLE+" SET synched='Y' WHERE key ='"+key+"' AND timestamp = "+timestamp+" AND synched ='N' ");
	}

	public long insert(long rowid,String gid,String key,String value,String user,String datatype,long timestamp,String synched) {

		/* We bind the values to the '?'s */
		this.insertStmt.bindLong(1, rowid);
		this.insertStmt.bindString(2, gid);
		this.insertStmt.bindString(3, key);
		this.insertStmt.bindString(4, value);
		this.insertStmt.bindString(5, user);
		this.insertStmt.bindString(6, datatype);
		this.insertStmt.bindLong(7, timestamp);
		this.insertStmt.bindString(8, synched);

		/* The actual insert to the database takes place here*/
		return this.insertStmt.executeInsert();
	}

	/* clear the contents of the database */
	public void clearRepositoryContents() {

		this.db.delete(CLIENT_TABLE, null, null);
		//this.db.delete(CLIENT_TABLE1, null, null);

	}

	public List<String[]> selectRecords(int gid) {
		List<String[]> records = new ArrayList<String[]>();
		Cursor cursor=db.query(CLIENT_TABLE, new String[] {"groupid","key","value","user", "datatype", "timestamp"},"synched='N' AND groupid="+gid, null, null, null, null);
		if (cursor.moveToFirst()) {
			do {
				records.add(new String[]{cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5)});
				//list.add(cursor.getString(1));
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		if(cursor==null)
		{
			records=null;
		}
		return records;
	}
	public boolean existNewRecords()
	{
		Cursor cursor = db.rawQuery("SELECT RECORDID FROM "+CLIENT_TABLE+" WHERE SYNCHED='N'", null);
		//Cursor cursor=db.query(CLIENT_TABLE, new String[] {"groupid","key","value","user", "datatype", "timestamp"},"synched='N'", null, null, null,null );
		if(cursor!=null)
			return true;
		else
			return false;
	}
	/*Select the unsynched records which were created after the given timestamp. It basically collects which need to be synched to the server stub.*/
	public List<String[]> selectNewRecords() {
		List<String[]> list = new ArrayList<String[]>();
		Cursor cursor=db.query(CLIENT_TABLE, new String[] {"groupid","key","value","user", "datatype", "timestamp"},"synched='N'", null, null, null, "timestamp desc, groupid");

		if (cursor.moveToFirst()) {
			do {
				list.add(new String[]{cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5)});
				//list.add(cursor.getString(1));
			} while (cursor.moveToNext());
		}
		if (cursor != null && !cursor.isClosed()) {
			cursor.close();
		}
		if(cursor==null)
		{
			list=null;
		}
		return list;
	}

	private static class OpenHelper extends SQLiteOpenHelper {

		OpenHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		/*Creates the table CLIENT_TABLE. Should be used only once - at the beginning.*/
		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL("CREATE TABLE " + CLIENT_TABLE  +"(RECORDID NUMBER,GROUPID TEXT,KEY TEXT,VALUE TEXT,USER TEXT,DATATYPE TEXT,TIMESTAMP NUMBER,SYNCHED TEXT, PRIMARY KEY(RECORDID,KEY,TIMESTAMP))");
			//db.execSQL("CREATE TABLE " + CLIENT_TABLE1  +"(record TEXT,timestamp NUMBER,seq TEXT)");
			db.execSQL("CREATE TABLE " + NAMESPACES_TABLE  +"(method TEXT,userid TEXT,namespace TEXT,permission TEXT,timestamp NUMBER)");
		}


		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w("Example", "Upgrading database, this will drop tables and recreate.");
			db.execSQL("DROP TABLE IF EXISTS " + CLIENT_TABLE);
			//db.execSQL("DROP TABLE IF EXISTS " + CLIENT_TABLE1);
			db.execSQL("DROP TABLE IF EXISTS " + NAMESPACES_TABLE);
			onCreate(db);
		}
	}
}