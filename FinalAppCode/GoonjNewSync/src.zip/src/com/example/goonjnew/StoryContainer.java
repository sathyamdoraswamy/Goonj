package com.example.goonjnew;

public class StoryContainer {
	
	int id;
	Story s;
	StoryTcRelation stc;
	IssueStoryRelation is;
	
	public StoryContainer(Story s, StoryTcRelation stc, IssueStoryRelation is )
	{
		this.s = s;
		this.stc = stc;
		this.is = is;
	}
}

