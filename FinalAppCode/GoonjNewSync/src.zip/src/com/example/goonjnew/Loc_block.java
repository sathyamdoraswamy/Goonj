package com.example.goonjnew;

public class Loc_block implements java.io.Serializable{

	int id;
	String name;
	int district_id;
	
	public void doJob(Object obj)
	{
		//inser values into db here
	}
}
