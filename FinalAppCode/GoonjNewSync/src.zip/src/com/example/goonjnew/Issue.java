package com.example.goonjnew;

public class Issue {
    int issue_id;
    String issue_name;
    String issue_description;
    String audio_media;
    String photo_media;
    String video_media;
    String status;
}
