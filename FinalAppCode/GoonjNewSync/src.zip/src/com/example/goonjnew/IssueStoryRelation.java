package com.example.goonjnew;

public class IssueStoryRelation implements java.io.Serializable{
    int is_id;
    int story_id;
    int issue_id;
}
