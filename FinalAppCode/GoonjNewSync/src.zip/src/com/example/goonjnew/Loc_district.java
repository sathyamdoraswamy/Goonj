package com.example.goonjnew;

public class Loc_district implements java.io.Serializable{

	int id;
	String name;
	int state_id;
	
	public void doJob(Object obj)
	{
		//insert value into db here
	}
}
