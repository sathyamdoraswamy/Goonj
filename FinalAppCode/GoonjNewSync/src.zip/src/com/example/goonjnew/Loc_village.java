package com.example.goonjnew;

public class Loc_village implements java.io.Serializable{

	int id;
	String village;
	int country_id;
	int state_id;
	int district_id;
	int block_id;
	
	public void doJob(Object obj)
	{
		//insert values into db here
	}
}
