package com.example.goonjnew;

public class Story implements java.io.Serializable {
	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	
	public int story_id;
	public int location_id;
	public int detail_id;
	public int ai_id;
	public String story_type;
	public String tags;
	public String title;
	public String transcript;
	public String date; //in a particular format
	public String audioPath;
	public String videoPath;
	public int views_count;
	public int rating;
	public String status_tag1;
	public String status_tag2;
	public String call_number;//this can be 64-bit int too
	public Boolean top_story;
	public int related_stories;
	public int gcall_duration;
	public String time_assigned;
	public String time_fetched;
	
	//add the topic and issue mapping fields serialazibility wise
	
	public String issueStoryPath;
	public String topicStoryPath;
	
	public void doJob(Object obj)
	{
		//insert corresponding data entry into my database
	}

}
