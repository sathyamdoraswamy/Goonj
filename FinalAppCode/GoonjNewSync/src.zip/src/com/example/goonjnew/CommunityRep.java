package com.example.goonjnew;

public class CommunityRep implements java.io.Serializable{

	int commnity_rep_id;
	String cr_name;
	String cr_photo;
	String cr_phone_number;
	String role;
	String cr_email;
	String cr_location_id;
	
	public void doJob(Object obj)
	{
		//insert value into db
	}
}
