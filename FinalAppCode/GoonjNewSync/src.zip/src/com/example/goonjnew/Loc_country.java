package com.example.goonjnew;

public class Loc_country implements java.io.Serializable{

	int id;
	String name;
	
	public void doJob(Object obj)
	{
		//insert values into db here
	}
}
