package com.example.goonjnew;

public class TopicChannel implements java.io.Serializable{
	
	int topic_channel_id;
	String topic_description;
	String topic;
	String topic_photo;
	
	public void doJob(Object obj)
	{
		//insert values into db
	}
}
