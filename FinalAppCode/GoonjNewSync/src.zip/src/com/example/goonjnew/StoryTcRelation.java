package com.example.goonjnew;

public class StoryTcRelation implements java.io.Serializable {
	   int stc_id;
	    int story_id;
	    int topic_channel_id;
}
