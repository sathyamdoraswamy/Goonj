package com.example.goonjnew;

public class Pair {
    String groupid;
    String namespace;
    Object obj;
}
